# Private-store plugin upgrade design

## Problem

OpenClaw can retain several npm project generations. `plugins install --force`
may stage a new package while discovery continues loading an older project,
including after restart. A production uninstall/install attempt also showed the
installer may return `EBUSY` after committing part of its work.

## Command

Add `perkos-a2a plugin-upgrade` as a narrowly scoped, idempotent transaction.
It accepts a verified npm-pack artifact and SHA-256, derives the existing agent
binding from protected OpenClaw configuration, and never prints configuration.

The command snapshots the strict JSON configuration and complete private npm
project store into a mode-0700 attempt directory with mode-0600 files. It then
uses only the official OpenClaw uninstall-by-ID and pinned install operations.
The exported A2A entry is restored with the existing EBUSY-safe config writer.
Success requires config validation, one discovered A2A plugin, exact target
version, and a resolved root inside the private npm project store.

Any failure restores both the complete store and configuration before returning
a fixed-schema redacted error. Re-running after success returns an idempotent
success when the single resolved generation already matches the artifact.

## Tests

Tests use temporary directories and a fake command runner: successful stale-root
replacement, EBUSY-after-install acceptance only when exact state is certified,
config preservation, idempotent rerun, install failure rollback, and failure
when discovery resolves outside the managed private store. No test uses network,
real credentials, production config, or message history.
