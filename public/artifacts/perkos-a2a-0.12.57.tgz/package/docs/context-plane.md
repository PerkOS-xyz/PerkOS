# PerkOS Context Plane

Project chat is scoped as `organization → project → conversation`. A runtime
must not treat its own long-term memory as the source of truth for the current
project roster, coordinator, tasks, or documents.

For every inbound project-chat message, `perkos-a2a` requests a versioned
`perkos.context.v1` snapshot from the PerkOS control plane using the agent's
existing relay credential. The API derives the owning tenant from that
credential and verifies all three boundaries before returning data:

1. the requested project belongs to that tenant;
2. the conversation belongs to that project; and
3. the agent is still present in both the current project roster and the
   conversation participant list.

The snapshot contains exact structured state (organization/project names,
coordinator, current members, tasks, and the document catalog) plus bounded
query-relevant document evidence. Recent conversation turns remain local to
the conversation's canonical history host and are added separately by the
chat client. This keeps multiple conversations isolated while giving every
thread the same current project facts.

Document excerpts are explicitly marked as untrusted reference data so text
inside a document cannot replace runtime or system instructions. Internal
tenant, wallet, project, conversation, document, and credential identifiers
stay in the transport layer and are omitted from model-facing context.

If the context API is unavailable or authorization has been revoked, the
plugin fails closed: it tells the runtime not to infer current project state
from stale memory. OpenClaw, Hermes, and custom runtimes continue to own their
model selection and routing; the Context Plane never sends a model override.

The v1 document selector is bounded lexical retrieval over the existing
Firestore document model. The versioned envelope deliberately separates exact
structured state from evidence, allowing a future hybrid vector/full-text
retriever to replace selection without changing the chat or runtime contract.
