# AP02: identidad del emisor local de Tools

El guard de proyecto de Tools exige actor firmado. La API ya incluye ese claim, pero A2A main todavía omite agent en el listener local y el MCP de board. Desplegar el guard sin corregir estos emisores bloquearía operaciones legítimas de los runtimes administrados.

Inferir actor desde convId en Tools violaría el diseño aprobado. Aceptarlo desde el body local permitiría suplantar otro agente. Se conserva la frontera: nombre del agente configurado al arrancar el bridge, validado antes de abrir listeners y estampado en el JWT firmado. wallet/role/convId siguen derivados del registro activo, nunca del body.

El signer admite agent opcional por compatibilidad con tokens no relacionados con proyectos. Los listeners usados por runtimes exigen identidad válida y siempre la incluyen; no arrancan sin ella. MCP conserva el nombre configurado, no el argumento de asignación de la herramienta. EVM/Solana, secretos, TTL y routing existentes no cambian.

Pruebas del HTTP local y MCP comprueban claim real, rechazo de configuración ausente/inválida e imposibilidad de override por body. Verificar JWT compilado contra el verificador Tools con fixtures. Sin consultas Firestore, gateways, agentes privados, publicación npm ni bump automático. Esta entrega prepara fuente; publicación/pins/imagen y aceptación Dev son pasos posteriores al merge aprobados por el usuario.

## Enmienda: dependencias de producción y gate reproducible

La auditoría del mismo lock detectó `proxy-addr` crítico y `qs` moderado. No demuestra explotación en PerkOS: el advisory de proxy-addr depende de una configuración específica de trust proxy. Antes de promover este paquete, fijar únicamente los parches compatibles `proxy-addr@2.0.8` y `qs@6.16.0` mediante overrides exactos, revisar el diff del lock y repetir instalación limpia con npm 11.20.0, tipos, pruebas, build y contrato JWT compilado.

CI ejecutará `npm audit --omit=dev --audit-level=high` explícitamente para bloquear vulnerabilidades altas o críticas en la resolución de producción. Registrar también el resultado completo: pasar ese umbral no equivale a certificar ausencia de toda vulnerabilidad, ni elimina alertas de desarrollo del repositorio. No usar audit fix --force, cambiar versiones mayores, publicar ni desplegar como parte de esta enmienda.

Fuentes: https://github.com/advisories/GHSA-jqcg-44mw-7w3h · https://github.com/advisories/GHSA-4mjr-xmp4-gh2g · https://github.com/advisories/GHSA-x5fp-wj9c-mxmx
