# A2A Tools actor release candidate

PR111 is merged as a518fc68383f07c36008af65e50ccc2fbfa25aba. The npm registry still lists 0.12.69; 0.12.70 is already used by a separately served immutable application artifact and bridge image. Neither consumer contains PR111. Do not replace that artifact or reuse its version.

Prepare 0.12.71 in package.json, the two root package-lock version fields, and openclaw.plugin.json. Update only repair fixtures that explicitly represent the current target; preserve older installed/mismatched versions and all assertions. No runtime logic, dependencies, permissions, endpoints, costs or gateway changes.

Verify clean installation with pinned npm11.20.0, production audit with explicit high threshold, version agreement, types, all tests, build and compiled maintenance fixture. Pack into a temporary directory, inspect package/manifests and test the extracted package plus the compiled Tools JWT contract. A local candidate checksum is not a published npm checksum.

After human review/merge and successful exact-main CI, publication requires approval and the trusted OIDC workflow against that exact merged revision. Then verify registry version/gitHead/integrity, prepare the application artifact and consumers/pins/image. Only promote the coordinated Dev guard after verifying actor-bearing emitters. Historical conversation authorization requires a new server-created thread or an explicitly approved provenance-based migration; never copy grants from editable metadata.

No publication/tag, private-agent update, reprovision, service restart, Firestore migration/rules deploy, QA/production promotion, signup or payment activation in this candidate-preparation step.
