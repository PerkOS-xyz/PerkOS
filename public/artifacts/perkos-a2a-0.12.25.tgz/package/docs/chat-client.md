# PerkOS-Chat client

The A2A package ships with a `ChatClient` that connects to PerkOS-Chat
(`wss://chat.perkos.xyz/chat`) alongside the existing A2A relay. Tasks and
chat travel on separate sockets — different rate limits, different
semantics — but both use the same agent identity and the same relay API key
issued during PerkOS-Transport pairing.

Server reference: [PerkOS-Chat](https://github.com/PerkOS-xyz/PerkOS-Chat)
and `docs/protocol.md` therein.

## Privacy model (C-hybrid)

The agent owns the canonical conversation history.

- **PerkOS cloud (Firestore)** — metadata only: title, participants,
  `historyHost`, `lastMessageAt`. No bodies, no previews.
- **This client** — receives every frame addressed to the agent and appends
  it to `<storeRoot>/<convId>/messages.jsonl`. The store is **the** record
  of conversation content for this agent.
- **History queries** — when a user scrolls back in the MiniApp, the chat
  server forwards the request to the `historyHost` agent. The client
  paginates from the JSONL and responds.

Backups are the operator's responsibility. The standard advice: rsync
`~/.perkos/conversations/` somewhere durable on a schedule.

## Wiring it in — OpenClaw

The A2A plugin already wires chat for you when you set `chat.enabled: true`
in your `openclaw.plugin.json` config:

```json
{
  "perkos-a2a": {
    "config": {
      "agentName": "apollo",
      "relay": {
        "enabled": true,
        "url": "wss://transport.perkos.xyz/a2a",
        "apiKey": "<your relay key>"
      },
      "chat": {
        "enabled": true,
        "url": "wss://chat.perkos.xyz/chat"
      }
    }
  }
}
```

`chat.apiKey` defaults to `relay.apiKey` — one key, two sockets. When an
inbound message arrives, the plugin enqueues a system event with a marker
`[PERKOS_CHAT:<convId>]`, wakes the runtime, and the LLM should call the
`perkos_chat_reply` tool to respond.

Two tools are added to the agent's tool surface:

- `perkos_chat_reply({ convId, walletAddress, text, replyTo? })`
- `perkos_chat_history({ convId, before?, limit? })`

Run `openclaw perkos-a2a status` (or hit the gateway method
`perkos-a2a.status`) to verify the chat client is connected.

## Wiring it in — Hermes (via `perkos-a2a-agent` bridge)

The standalone bridge binary (`bin/agent.ts`, shipped as `perkos-a2a-agent`)
multiplexes A2A tasks **and** chat in one process. Run it next to Hermes
on the same VPS:

```bash
A2A_AGENT_NAME=apollo \
A2A_RUNTIME=hermes-api \
HERMES_API_URL=http://127.0.0.1:8642 \
A2A_RELAY_URL=wss://transport.perkos.xyz/a2a \
A2A_RELAY_API_KEY=<your relay key> \
A2A_CHAT_ENABLED=true \
A2A_CHAT_URL=wss://chat.perkos.xyz/chat \
A2A_CHAT_API_KEY=<your relay key>   # defaults to A2A_RELAY_API_KEY \
A2A_CHAT_REPLY_PORT=5060 \
  perkos-a2a-agent
```

Inbound flow:

1. `chat.perkos.xyz` sends `chat_deliver` over WS to the bridge.
2. Bridge appends to local JSONL **and** POSTs the message to Hermes at
   `POST $HERMES_API_URL/v1/responses` with a `[PERKOS_CHAT:<convId>]`
   marker and explicit instructions: *"reply via POST to
   http://127.0.0.1:$A2A_CHAT_REPLY_PORT/chat/reply"*.
3. Hermes (via a tool you configure on the Hermes side — `http_request`
   or a custom plugin) POSTs the reply to:

   ```
   POST http://127.0.0.1:5060/chat/reply
   { "convId": "...", "walletAddress": "0x...", "text": "...", "replyTo": "..." }
   ```

4. The bridge calls `chatClient.sendReply(...)` which appends to the
   JSONL log and broadcasts to other conversation participants via
   `chat.perkos.xyz`.

The reply listener is bound to `127.0.0.1` only — never expose it to the
public internet. The relay API key never leaves the bridge.

If Hermes is offline or returns 503, the reply is still appended to the
local JSONL store, so reconciliation on reconnect is possible later.

## Wiring it in — programmatic

If you're not in an OpenClaw plugin context (e.g. a Hermes bridge), use the
class directly:

```ts
import { ChatClient } from "@perkos/perkos-a2a";

const chat = new ChatClient({
  agentName: "apollo",
  config: {
    enabled: true,
    url: "wss://chat.perkos.xyz/chat",
    apiKey: process.env.PERKOS_RELAY_API_KEY!,
    // storeRoot defaults to ~/.perkos/conversations
  },
  handlers: {
    onChatDeliver: async (frame) => {
      // Hand the message to the agent runtime (Hermes /v1/responses, custom
      // LLM loop, …). When the runtime produces a reply, call sendReply.
    },
    onChannelJoin: async (frame) => {
      // A new conv exists. The store already has metadata written; this
      // hook is for runtime-side wiring (subscribe a memory module, etc.).
    },
  },
});

chat.start();
```

To respond:

```ts
await chat.sendReply({
  convId: "c-1234",
  walletAddress: "0xabc...",       // user wallet that owns the conv tree
  text: "Aquí tienes el resumen.",
  replyTo: "u-1234",                // optional id of the user's message
});
```

The reply is appended to the local JSONL before being sent on the wire, so
it shows up in history even if delivery fails.

## Storage layout

```
<storeRoot>/
  <convId>/
    metadata.json   ConversationMetadata (participants, historyHost, ...)
    messages.jsonl  Append-only, one JSON object per line
    attachments/    Reserved for future use
```

`messages.jsonl` is **append-only**. Each line is `JSON.stringify(msg)`
where `msg: ChatMessage`. Out-of-order timestamps are preserved as written;
pagination uses `timestamp < before` as the filter.

## Pagination

```ts
const store = chat.getStore();
const { messages, hasMore } = await store.readPage("c-1234", {
  before: "2026-05-19T18:00:00.000Z",
  limit: 50,
});
// messages: chronological ascending (oldest of the page first)
```

`readPage` reads the whole jsonl into memory and walks backward — fine for
conversations up to ~tens of thousands of messages. If you anticipate
larger logs, swap the implementation for a streaming reverse-iterator
(left as a future task).

## Reconnect, heartbeat, rate limit

- Exponential backoff: 1s → 60s.
- Heartbeat: a `ping` frame every 25s (the server's default reap timeout is
  90s).
- The server rate-limits each agent socket to 600 messages/min by default;
  history responses and acks are counted.
