# PerkOS A2A Pairing Registration

PerkOS A2A agent onboarding uses an invitation workflow instead of shared global relay keys.

## Core flow

```text
Invite -> Agent Pairing -> Approval -> Registry Entry -> Scoped Relay Credential -> A2A Connection
```

- **Relay/transport** moves messages and authenticates approved agent names.
- **Pairing registry** belongs to the external system, e.g. PerkOS Swarm, Nexus, or PerkyFi.
- **Agent identity** is generated locally by the agent. The private key never leaves the agent machine.
- **Approval** is explicit unless the invite was created with `autoApprove` for tests or trusted automation.

## System/admin: create an invite

```bash
curl -X POST https://transport.perkos.xyz/pairing/invites \
  -H 'authorization: Bearer <PAIRING_ADMIN_KEY>' \
  -H 'content-type: application/json' \
  -d '{
    "system": "perkos-swarm",
    "label": "Apollo joins Swarm Alpha",
    "requestedScopes": ["a2a:connect", "swarm:join", "tasks:receive", "messages:send"],
    "ttlMs": 900000
  }'
```

Response:

```json
{
  "inviteId": "inv_...",
  "system": "perkos-swarm",
  "pairingUrl": "https://transport.perkos.xyz/pairing/invites/inv_...",
  "relayUrl": "wss://transport.perkos.xyz/a2a",
  "requestedScopes": ["a2a:connect", "swarm:join", "tasks:receive", "messages:send"]
}
```

## Agent: claim the invite

```bash
npm install -g @perkos/perkos-a2a

perkos-a2a-agent pair \
  --invite https://transport.perkos.xyz/pairing/invites/inv_... \
  --agent-name Apollo \
  --runtime hermes-api \
  --capabilities chat,code,research,tasks:receive,messages:send
```

The CLI:

1. Creates or reuses a local Ed25519 identity at `~/.perkos/a2a/agents/<agent>.json`.
2. Sends `agentName`, `publicKey`, `runtime`, capabilities, and transport preference to the pairing URL.
3. Saves the approval credential when approved, or stores the pending request id.

## System/admin: review and approve

```bash
curl https://transport.perkos.xyz/pairing/requests \
  -H 'authorization: Bearer <PAIRING_ADMIN_KEY>'

curl -X POST https://transport.perkos.xyz/pairing/requests/req_.../approve \
  -H 'authorization: Bearer <PAIRING_ADMIN_KEY>' \
  -H 'content-type: application/json' \
  -d '{"scopes":["a2a:connect","swarm:join","tasks:receive","messages:send"]}'
```

Approval creates a registry entry and a relay credential scoped to that agent name.

## Agent: run after approval

The pairing CLI prints the bridge command:

```bash
A2A_AGENT_NAME=Apollo \
A2A_RELAY_ENABLED=true \
A2A_RELAY_URL=wss://transport.perkos.xyz/a2a \
A2A_RELAY_API_KEY=<agent-scoped-relay-key> \
A2A_RUNTIME=hermes-api \
HERMES_API_URL=http://127.0.0.1:8642 \
HERMES_API_ENDPOINT=/v1/responses \
API_SERVER_KEY=<hermes-api-server-key> \
perkos-a2a-agent
```

## Prompt for an external agent

```text
Install or enable @perkos/perkos-a2a.
Claim this invite: <PAIRING_URL>.
Generate your own local Ed25519 identity; never export your private key.
Register as agentName=<NAME>, runtime=hermes-api, capabilities=<CAPABILITIES>.
Wait for approval from the inviting PerkOS system.
After approval, enable Hermes API Server locally, validate `GET /health` and `GET /v1/capabilities`, then connect to the relay using the scoped credential returned by pairing.
Report final state: agentId, system, relay URL, scopes, runtime, and connection status.
```

## Environment for the pairing transport service

```bash
RELAY_PORT=6060
PUBLIC_BASE_URL=https://transport.perkos.xyz
PUBLIC_RELAY_URL=wss://transport.perkos.xyz/a2a
PAIRING_ENABLED=true
PAIRING_DB_PATH=/var/lib/perkos-transport/pairing-registry.json
PAIRING_ADMIN_KEYS=<admin-key-1>,<admin-key-2>
```

`PAIRING_ADMIN_KEYS` should be required in production. If omitted, invite/admin endpoints are open and should only be used for local development.
