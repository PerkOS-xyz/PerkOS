# Nexus Communications Server Pattern

> Deployment note: the standalone communications/transport server source now lives in [`PerkOS-xyz/PerkOS-Transport`](https://github.com/PerkOS-xyz/PerkOS-Transport). This package remains the A2A protocol/plugin implementation used by clients and runtimes.


This is the recommended PerkOS A2A topology for Nexus-style project rooms and agent swarms.

## Goals

- Keep user/runtime agents behind NAT with outbound-only WebSocket connections.
- Use the relay as a registrar/rendezvous server, not as an unrestricted public chat server.
- Let a product backend orchestrate project-room messages, task assignment, persistence, and auth.
- Allow OpenClaw/Hermes workers to receive A2A envelopes and call back into the backend with results.

## Components

```text
Nexus UI
  -> Nexus Backend / communications server
      -> PerkOS A2A orchestrator client
          -> PerkOS A2A relay hub
              -> OpenClaw or Hermes runtime worker
                  -> authenticated callback to Nexus Backend
```

### Relay hub

Run the relay on a stable host or locally for development:

```bash
RELAY_PORT=6060 \
RELAY_API_KEYS=devkey \
a2a-relay
```

For production, prefer `RELAY_AGENTS`/`registeredAgents` so every agent has an explicit approved registration key instead of a shared relay key.

### Backend / communications server

The backend owns durable product state. It should:

1. register or launch runtime agents and persist their stable `agentId`;
2. create an A2A client named after the backend/orchestrator;
3. dispatch structured envelopes to `agentId` targets;
4. receive authenticated runtime callbacks;
5. persist messages, task logs, artifacts, and status.

Envelope examples:

```json
{
  "kind": "nexus.agent_discussion",
  "version": 1,
  "walletAddress": "<wallet>",
  "projectId": "<project>",
  "projectName": "Demo Project",
  "projectGoal": "Coordinate agents",
  "topic": "What should we build first?",
  "agentId": "<stable-agent-id>",
  "agentName": "Builder Agent",
  "agentRuntime": "OpenClaw",
  "agentPlugins": ["github", "browser", "storage"]
}
```

```json
{
  "kind": "nexus.project_task",
  "version": 1,
  "walletAddress": "<wallet>",
  "projectId": "<project>",
  "taskId": "<task>",
  "taskName": "Prepare first deliverable",
  "taskPrompt": "Implement the first slice",
  "agentId": "<stable-agent-id>",
  "agentName": "Builder Agent",
  "agentRuntime": "OpenClaw"
}
```

### Runtime worker

A runtime worker should:

- connect outbound to the relay using `NEXUS_A2A_RELAY_URL` and `NEXUS_A2A_RELAY_API_KEY`;
- register with `agentName = stable agentId` to avoid display-name collisions;
- validate envelope kind and target `agentId`;
- execute the requested work or discussion action;
- call back to the backend using a bearer token or equivalent service auth.

## Local smoke test

NexusApp includes a local smoke test that starts:

- fake Nexus backend callback server;
- embedded PerkOS A2A relay;
- real Nexus runtime worker process;
- A2A orchestrator client.

It verifies both `nexus.agent_discussion` and `nexus.project_task` envelopes reach the worker and produce backend callbacks:

```bash
cd NexusApp/Backend
npm run smoke:a2a
```

Expected output:

```text
ok - fake Nexus backend listening
ok - PerkOS A2A relay listening
ok - orchestrator discovered runtime worker over relay
ok - A2A discussion envelope reached worker and posted callback
ok - A2A project-task envelope reached worker and executed callback
ok - a2a local smoke passed
```

## Live PerkOS transport endpoint

Current app-server deployment:

- VPS: `62.238.28.49`
- Public secure endpoint: `wss://transport.perkos.xyz/a2a`
- TLS: Let's Encrypt via the existing Caddy proxy
- Container: `perkos-a2a-relay`
- Server path: `/opt/perkos-a2a-relay`
- Relay secret: stored only on the VPS in `/opt/perkos-a2a-relay/.env`

Use this from Nexus/worker env:

```bash
NEXUS_A2A_ENABLED=true
NEXUS_A2A_RELAY_URL=wss://transport.perkos.xyz/a2a
NEXUS_A2A_RELAY_API_KEY=<relay-key-from-vps-env>
```

## Docker deployment

The repo includes a minimal relay runner for VPS/app-server deployments:

- `deploy/Dockerfile`
- `deploy/relay-runner.mjs`

Example compose service:

```yaml
services:
  relay:
    build: .
    restart: unless-stopped
    env_file: .env
    expose:
      - "6060"
```

`.env` should contain either a temporary shared key:

```bash
RELAY_PORT=6060
RELAY_API_KEYS=<generated-shared-dev-key>
```

or, preferably for production, explicit per-agent keys:

```bash
RELAY_PORT=6060
RELAY_AGENTS="nexus-backend:<key>,builder-agent:<key>"
```

If the app server already has Caddy/nginx, route a secure WebSocket subdomain to the relay container, for example:

```caddyfile
transport.perkos.xyz {
  encode gzip zstd

  @health path /health
  respond @health "ok transport.perkos.xyz" 200

  reverse_proxy perkos-a2a-relay:6060
}
```

Caddy will automatically issue and renew Let's Encrypt certificates when DNS points to the server.

## Production hardening checklist

- Use explicit registered agents and per-agent registration keys.
- Keep callback endpoints authenticated and scoped by project/agent.
- Store task/message receipts with A2A task IDs for replay/debugging.
- Add relay health and peer discovery endpoints to the backend.
- Do not put secrets, private keys, seed phrases, or cloud credentials in A2A payloads.
