# PerkOS multi-agent demo — provisioning playbook

End-to-end recipe for standing up the three-agent demo on a Hetzner VPS
(or any Linux host with Docker, Caddy, and outbound HTTPS). Read it
once, then `scripts/demo/` does most of the work.

## Topology

```
┌──── PerkOS-Transport (transport.perkos.xyz) ────┐
│  tasks routing, pairing registry                 │
└──────────────────────────────────────────────────┘
            ▲                               ▲
            │ wss /a2a                      │ wss /a2a
            │                               │
┌──── PerkOS-Chat (chat.perkos.xyz) ────┐  │
│  chat routing, Firebase metadata write │  │
└────────────────────────────────────────┘  │
       ▲                                    │
       │ wss /chat (user)                   │ wss /chat
       │                                    │ (agent)
   browser                                  │
                                            │
   ┌────────────────────────────────────────┴────────┐
   │ Apollo (orchestrator, Hermes runtime)            │
   │ Builder (worker, OpenClaw)                       │
   │ QA      (worker, OpenClaw)                       │
   │   each: perkos-a2a-agent → Transport + Chat WS   │
   └─────────────────────────────────────────────────-┘
```

For the demo we use a **single VPS** with all three agents running as
separate `perkos-a2a-agent` processes (different ports, different
config dirs). Apollo runs **Hermes** as its runtime — the others run
**OpenClaw**.

## Prerequisites on the VPS

1. Docker + docker compose
2. Caddy already serving `transport.perkos.xyz` and `chat.perkos.xyz`
3. Hermes Agent installed and reachable on `http://127.0.0.1:8642`
   (the Apollo orchestrator) — see [hermes-workspace install
   guide](https://github.com/NousResearch/hermes-agent)
4. OpenClaw installed (the worker agents) — see [OpenClaw
   docs](https://openclaw.dev) — they don't need a separate HTTP
   server; the A2A plugin handles networking
5. Node.js 22+ on the host (or use the published
   `@perkos/perkos-a2a` npm package)
6. The Transport admin key (`PAIRING_ADMIN_KEY` from Transport's
   `.env`) — needed to mint invites
7. SSH access as a non-root user with sudo

## Step 0 — Decide identities

```
ORG_SYSTEM=perkos-demo
PROJECT_ID=demo-q4

# Three agents, one orchestrator + two workers
APOLLO_NAME=apollo
BUILDER_NAME=builder
QA_NAME=qa
```

## Step 1 — Mint Transport pairing invites

For each agent, ask Transport for an invite. The wrapper script in
`scripts/demo/mint-pairing.sh` does it; or call the HTTP API directly:

```bash
export TRANSPORT_BASE=https://transport.perkos.xyz
export TRANSPORT_ADMIN_KEY=<from your Transport .env>

for agent in apollo builder qa; do
  echo "=== minting invite for $agent ==="
  curl -fsS -X POST "$TRANSPORT_BASE/api/systems/perkos-demo/agents/invites" \
    -H "x-api-key: $TRANSPORT_ADMIN_KEY" \
    -H "content-type: application/json" \
    -d "{
      \"agentName\": \"$agent\",
      \"runtime\": \"$( [[ $agent == apollo ]] && echo hermes-api || echo openclaw )\",
      \"scopes\": [\"a2a:connect\", \"tasks:receive\", \"messages:send\", \"chat:send\"]
    }" | tee /tmp/invite-$agent.json
done
```

Each invite response looks like:

```json
{
  "inviteId": "inv_…",
  "pairingUrl": "https://transport.perkos.xyz/pairing/invites/inv_…",
  "expiresAt": "2026-05-20T..."
}
```

Keep them — the agent uses the URL to claim and the operator (you)
approves.

## Step 2 — Claim and approve

The pairing flow is two-step: the agent claims with a public key, then
admin approves to issue the scoped `relayApiKey`.

For the demo we **auto-approve** by passing the admin key on the claim
step. `scripts/demo/claim-and-approve.sh` wraps this:

```bash
scripts/demo/claim-and-approve.sh apollo  /tmp/invite-apollo.json
scripts/demo/claim-and-approve.sh builder /tmp/invite-builder.json
scripts/demo/claim-and-approve.sh qa      /tmp/invite-qa.json
```

Each call prints the `relayApiKey` for that agent. Save them:

```bash
APOLLO_KEY=…
BUILDER_KEY=…
QA_KEY=…
```

## Step 3 — Update chat.perkos.xyz registry

Until the production bridge between Transport's pairing registry and
Chat's agent-key store lands, chat.perkos.xyz reads agent keys from
its `RELAY_API_KEYS` env var. SSH to the chat host and add the new
keys:

```bash
ssh hetzner
sudo nano /opt/PerkOS-Chat/.env

# Update or extend:
RELAY_API_KEYS=apollo:<APOLLO_KEY>,builder:<BUILDER_KEY>,qa:<QA_KEY>

# Reload:
cd /opt/PerkOS-Chat
docker compose -f docker-compose.example.yml up -d
```

Verify:

```bash
curl https://chat.perkos.xyz/health | jq .agents
# expect 0 (no agents connected yet — that's fine)
```

## Step 4 — Start Apollo (Hermes orchestrator)

```bash
# On the Hermes host:
export A2A_AGENT_NAME=apollo
export A2A_RUNTIME=hermes-api
export HERMES_API_URL=http://127.0.0.1:8642
export A2A_RELAY_URL=wss://transport.perkos.xyz/a2a
export A2A_RELAY_API_KEY=<APOLLO_KEY>
export A2A_CHAT_ENABLED=true
export A2A_CHAT_URL=wss://chat.perkos.xyz/chat
export A2A_CHAT_API_KEY=<APOLLO_KEY>
export A2A_CHAT_REPLY_PORT=5060
export A2A_PORT=5050
export A2A_PEERS='{"builder":"http://127.0.0.1:5051","qa":"http://127.0.0.1:5052"}'

npx -p @perkos/perkos-a2a perkos-a2a-agent
```

A systemd unit template is in `scripts/demo/systemd/apollo.service`.

## Step 5 — Start Builder + QA (OpenClaw workers)

OpenClaw agents load the A2A plugin natively. Drop this config into
each worker's OpenClaw plugins directory:

```jsonc
// builder.plugin.config.json
{
  "perkos-a2a": {
    "config": {
      "agentName": "builder",
      "port": 5051,
      "bindHost": "127.0.0.1",
      "mode": "client-only",
      "peers": {
        "apollo": "http://127.0.0.1:5050"
      },
      "relay": {
        "enabled": true,
        "url": "wss://transport.perkos.xyz/a2a",
        "apiKey": "<BUILDER_KEY>"
      },
      "chat": {
        "enabled": true,
        "url": "wss://chat.perkos.xyz/chat",
        "apiKey": "<BUILDER_KEY>"
      },
      "runtime": {
        "kind": "openclaw"
      }
    }
  }
}
```

`qa` is identical except `agentName`, `port=5052`, and `apiKey`.

Restart each OpenClaw process to pick up the plugin config.

## Step 6 — Verify all three connect

```bash
scripts/demo/verify.sh
```

Output should look like:

```
✓ transport.perkos.xyz reachable
✓ chat.perkos.xyz reachable
✓ apollo  — A2A connected, chat connected
✓ builder — A2A connected, chat connected
✓ qa      — A2A connected, chat connected
```

Or hit the health endpoints manually:

```bash
curl https://chat.perkos.xyz/health | jq .agents
# expect 3
curl https://transport.perkos.xyz/health | jq .connectedAgents
# expect 3
curl "https://transport.perkos.xyz/api/agents/apollo/heartbeat" -H "x-api-key: $TRANSPORT_ADMIN_KEY" | jq
# expect { "ok": true, "approved": true, "connected": true }
```

## Step 7 — Smoke from the MiniApp

Open the MiniApp, sign in with a wallet, and walk through the
[chat E2E checklist](https://github.com/PerkOS-xyz/PerkOS/blob/main/docs/CHAT-E2E.md).

Quickest happy-path: click **+ New**, pick "Direct message" + apollo,
type "hola apollo" — you should see Apollo's reply within 5 seconds
(Hermes processing time).

## Troubleshooting

| Symptom | First-pass diagnosis |
|---|---|
| MiniApp sidebar empty | Firestore rules deployed? — see `Perkos/firestore.rules` |
| `auth_error` on the chat WS | Firebase project mismatch between MiniApp and chat.perkos.xyz |
| Agent not connecting | Check the `RELAY_API_KEYS` value matches what claim-and-approve issued |
| Apollo gets the chat_deliver but no reply | Hermes is not configured to POST to `127.0.0.1:5060/chat/reply` (see `docs/chat-client.md` "Wiring it in — Hermes") |
| `HOST_OFFLINE` banner stays up | The host agent's WS dropped; check the agent process logs |
| Builder/QA never receive sub-tasks | Apollo's peer config wrong; check the JSON peers map in apollo's env |

## Decommissioning the demo

```bash
# Revoke each agent on Transport
for agent in apollo builder qa; do
  curl -X POST "$TRANSPORT_BASE/pairing/agents/$agent/revoke" \
    -H "x-api-key: $TRANSPORT_ADMIN_KEY"
done

# Remove from chat.perkos.xyz
ssh hetzner 'sudo sed -i "s/RELAY_API_KEYS=.*/RELAY_API_KEYS=/" /opt/PerkOS-Chat/.env && \
  cd /opt/PerkOS-Chat && docker compose -f docker-compose.example.yml up -d'

# Stop the agent processes (systemd or direct)
```

Conversation metadata stays in Firestore. Conversation content stays
in each agent's `~/.perkos/conversations/` jsonl. Delete those if you
want a clean wipe.
