# Identidad del control plane desde config o entorno

## Hallazgo

El bridge Hermes instalado por `update-hermes` puede conservar `PERKOS_HEARTBEAT_URL` y `A2A_RELAY_API_KEY` en el entorno del servicio. Heartbeat ya lee ambos orígenes, pero los handlers de mantenimiento y Voice sólo consultaban el JSON del plugin. Así, una instancia podía anunciar una capability Chat-bound válida y responder `a2a_identity_unavailable` al recibir el marcador.

## Decisión

Un resolvedor compartido aplica una precedencia única: configuración explícita del plugin y luego variables del servicio. Valida una URL de heartbeat con la ruta exacta `/agents/<id>/heartbeat`, deriva el API base y nunca registra ni devuelve la credencial fuera del proceso. Mantenimiento y Voice consumen el mismo resolvedor para impedir nuevas divergencias.

## Seguridad y verificación

La ausencia de URL o credencial continúa fallando cerrado. La capability sigue ligada a la conexión Chat y a `bridgeInstanceId`; este cambio sólo hace accesible al handler la misma identidad que ya usa heartbeat. Las pruebas cubren identidad completa en config, fallback completo por entorno y rechazo de identidad incompleta o URL inválida.

> Relacionado: [[PerkOS-Projects/README]] · [[PerkOS-A2A]] · [[PerkOS-API]] · [[PerkOS]] · [[PerkOS-Voice]]
