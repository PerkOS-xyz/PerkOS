# Entrega durable de turnos de chat

Diseño aprobado: separar la espera del navegador de la ejecución, guardar el
resultado en el backend privado antes de emitir y reintentar la entrega sin
repetir herramientas. No modificar gateways Voice ni credenciales.

## Implementación

- Journal privado de turnos: accepted/running/completed/uncertain. Una ejecución
  por entrada estable; serialización por conversación y concurrencia acotada.
- El chat HTTP no hereda el deadline de 240 s del transporte de tareas. La
  cancelación de un consumidor no cancela el trabajador. Usar HTTP sin límite
  implícito de headers/body de fetch para turnos largos.
- Con `/v1/runs` configurado: guardar run_id inmediatamente y consultar estado;
  reanudar consultas después de reiniciar el puente. No repetir POST si su
  resultado es ambiguo. No asumir soporte en runtimes privados sin verificarlo.
- Con Responses síncrono: conservar la conexión propietaria hasta terminar.
  Un reinicio sin checkpoint no es recuperable de forma segura: estado incierto,
  nunca reejecución automática. Esta limitación debe permanecer explícita.
- Outbox privada con resultado/ID/timestamp/replyTo estables. Guardar antes de
  transmitir, consumir ACK y reenviar tras reconectar. Historial y UI deduplican.
- Progreso correlacionado y transitorio. App muestra demora no terminal, consume
  progreso, reconcilia live/history y vuelve a consultar al reconectar.
- OpenClaw respeta el límite configurado por su runtime, sin cap de 75 s; no
  ejecutar fallback después de iniciar un turno de resultado incierto.

## Verificación

Pruebas de turnos >90/>240 s, aborto de consumidor, resultado tras cierre de App,
ACK perdido, WS offline, recuperación outbox/journal, correlación y deduplicación.
HTTP controlado real y E2E local largo con salida sintética, sin herramientas Voice.
Publicación y verificación de la versión instalada son gates separados del código.
