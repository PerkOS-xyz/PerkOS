# Optional Voice package resolution

## Decision

PerkOS Voice remains a capability parallel to A2A, but A2A declares
`@perkos/perkos-voice` as an `optionalDependency`. This places the package next
to A2A in npm-managed private runtime installations, where the existing dynamic
`import("@perkos/perkos-voice/a2a")` can resolve it normally. Unsupported
runtimes still report their runtime/model limitation and never enable calls.

The alternatives were an optional peer dependency, which would require every
runtime installer to perform a second correctly scoped install, or resolving a
global package path, which is host-specific and bypasses normal Node package
resolution. The optional dependency is preferred because npm may omit or fail
it without making A2A installation fail, while a successful installation is
discoverable without secrets, custom paths, or model involvement.

## Verification

Release validation must prove manifest and lockfile agreement, the existing
missing-package fallback, successful dynamic delegation, the full A2A suite,
and a clean external install that imports both package subpaths. The package
remains absent from A2A responses and no Voice credential crosses the A2A
boundary.
