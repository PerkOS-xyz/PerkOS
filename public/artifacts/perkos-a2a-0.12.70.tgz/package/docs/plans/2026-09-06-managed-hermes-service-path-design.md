# Actualización administrada de Hermes bajo launchd

Diseño solicitado: corregir el actualizador A2A, sin modificar Voice, Hermes,
la UI, credenciales o endpoints. La existencia del archivo npx no prueba que
su shebang pueda encontrar Node en un servicio.

## Decisión

Se prefiere Node absoluto + CLI de npx con PATH corregido, frente a únicamente
corregir PATH y seguir dependiendo del shebang. El mismo entorno se utiliza
en el runner separado, la comprobación de npx y el comando de actualización.
Los nuevos servicios incluyen un PATH explícito con el directorio de su Node.

Los errores públicos están limitados a códigos conocidos. Los resultados
persistidos no contienen identidades, rutas, endpoints ni salida de comandos.
La correlación privada vive separada, conserva la validación de identidad y
entorno al reintentar, y no conserva la credencial del trabajo finalizado.
Los recibos antiguos se migran antes de reintentarlos.

## Verificación y límites

- Reproducir el fallo env-node con un subproceso y PATH de servicio.
- Probar CLI con Node absoluto y PATH idéntico, incluyendo subprocesos hijos.
- Probar error de ejecución, npx ausente, recibo inválido y versión incorrecta.
- Probar retención/reintento, aislamiento de entorno y saneamiento de recibos.
- Validar el paquete compilado, no solamente imports del código fuente.
- No confundir un fixture con una actualización real de Athena.

## Publicación y migración

La versión publicada 0.12.67 es inmutable; el arreglo se prepara en 0.12.68.
Un bridge que todavía ejecuta el runner anterior no adquiere este arreglo sólo
por publicar npm. Antes de reintentar desde la App necesita una migración
controlada del PATH de su servicio y del bridge, autorizada por su propietario,
o un canal de mantenimiento independiente ya instalado. No usar npx interactivo
ni delegarlo al modelo por chat. No modificar servicios Voice. La actualización
real sólo se considera completa con recibo terminal y versión del bridge activo
coincidentes con el objetivo. Hasta entonces la validación en el host queda pendiente.
