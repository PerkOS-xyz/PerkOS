# Hermes secure self-update

## Decision

Add an explicit `update-hermes` command for an already-connected native macOS
Hermes agent. The command accepts only the PerkOS agent id, locates that
identity's private managed installation, and reuses its existing relay
credential, agent name, relay URL, chat URL, and platform API URL without
printing or copying any secret into the conversation.

The update must fail closed when the managed configuration is absent,
malformed, or belongs to a different identity. It must never fall back from
the update path to a new production connection. Fresh invitations continue to
use `connect-hermes` and provide their scoped credential once.

This is preferable to asking an external private agent to paste its credential
again, exporting secrets into a model-visible prompt, or relying on a global
npm installation that may not match the supervised runtime.

## Verification

Tests cover successful reuse, identity mismatch, missing managed state,
preservation of Dev endpoints, and secret-free CLI output. The full package
suite, typecheck, build, and a clean package install must remain green.
