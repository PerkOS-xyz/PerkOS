# Environment-scoped Hermes connection

The native `connect-hermes` installer must not infer a PerkOS environment from
an agent credential. The invitation explicitly supplies Transport, Chat, and
API endpoints; the CLI persists those exact values in the bridge config and
launchd service. When no values are supplied, the existing Production defaults
remain for backward compatibility.

This prevents a Development or QA credential from silently dialing Production.
Tests cover the persisted relay, chat, and heartbeat URLs. No runtime model,
memory, Hermes credentials, or local API routing changes.
