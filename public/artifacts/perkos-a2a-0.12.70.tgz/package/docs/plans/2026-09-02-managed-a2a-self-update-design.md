# Managed A2A self-update

## Decision

Replace the model-facing `Update integration` prompt with a platform-managed,
one-time maintenance request. The model must never be asked to execute npm or
shell commands. PerkOS App creates the request through the authenticated API,
sends only an exact opaque marker through the existing agent chat, and polls
the API for the durable result.

The installed A2A bridge intercepts the marker before model delivery, claims
the request using its existing relay credential, acknowledges it, and launches
a detached updater. The updater reuses the managed Hermes identity and
configuration, reports a fixed-schema result to the API, and never includes a
credential, command output, or arbitrary model text in the response.

## Protocol

1. An authenticated owner creates an update request for an invited agent.
2. The API chooses the allow-listed target package version, stores a random
   request id with a short expiry, and returns `PERKOS_A2A_UPDATE:<requestId>`.
3. A compatible bridge validates the exact marker and claims the request with
   its relay API key. A Firestore transaction makes this claim single-use.
4. The bridge returns a fixed acknowledgement and starts a detached Hermes
   updater from a mode-0600 local job file.
5. The updater runs the existing identity-preserving `update-hermes` flow and
   reports `completed` or `failed` to the API with redacted, bounded fields.
6. PerkOS App polls the request resource and renders the durable state:
   `pending`, `claimed`, `running`, `completed`, `failed`, or `expired`.

The opaque marker is not an authorization credential. Claim and report calls
still require the agent's relay key, and the API verifies that the request is
pending, unexpired, and belongs to that exact agent. Target npm specs are never
accepted from either the App or the agent.

## Compatibility and fallback

Bridges released before this protocol cannot intercept the marker. The UI must
therefore expose managed update only when runtime evidence advertises support.
Older or unknown installations show `Bootstrap required` and a concise manual
owner instruction. The fallback must not claim that an automatic update was
started.

The first implementation supports managed Hermes installations. Voice remains
an independent optional capability: A2A update availability must not imply
Voice support, installation, or enrollment.

## Failure handling

- Requests expire and are idempotent after a terminal state.
- Duplicate claims return the existing state without launching another update.
- The detached updater writes no secret to argv, logs, chat, or API results.
- A restart or lost chat reply does not lose the result because API state is
  authoritative.
- Unsupported runtimes fail closed with a fixed error code.
- The UI stops polling on terminal state or expiry and permits an owner retry
  by creating a new request.

## Verification

API tests cover ownership, relay authentication, expiry, single-use claims,
idempotent reports, and target-version allow-listing. A2A tests cover strict
marker parsing, model bypass, secure job creation, detached launch, redaction,
and result reporting. App tests cover supported and bootstrap-required states,
request dispatch, polling, terminal rendering, retry, localization, and the
absence of shell commands in chat prompts.
