# Chat-bound maintenance capability

## Problem

The platform inferred managed-update support from the reported A2A package
version. A bridge could therefore publish `0.12.63` while another legacy
process owned the active Chat registration. The App offered an update, but the
marker remained pending because no active consumer claimed it.

## Decision

Managed maintenance is fail-closed and requires all of the following:

1. Hermes runtime and A2A package `>=0.12.64`.
2. Protocol-v1 capability in a recent heartbeat.
3. A UUID `bridgeInstanceId` generated once per bridge process.
4. An authenticated Chat connection owned by that same process.
5. A request and claim addressed to the same `bridgeInstanceId`.

The standalone bridge reports capability immediately after Chat authentication
and revokes it immediately after disconnect. The API leases the evidence for
125 seconds using server time. Every ordinary heartbeat without the capability
clears it. The App only renders the managed action while that lease is valid.

## Failure behavior

- A compatible semver without fresh capability shows bootstrap required.
- A duplicate or superseded process cannot claim a marker addressed elsewhere.
- Expired capability prevents request creation with `BOOTSTRAP_REQUIRED`.
- Voice remains an independent optional capability.

## Migration

Version `0.12.63` cannot advertise this stronger contract. Existing Hermes
agents need the one-time `update-hermes` bootstrap to `0.12.64`; subsequent
updates can use the managed marker flow.
