# Durable App chat delivery

Version 0.12.67 separates chat execution from delivery waiters. It does not change
Voice lifecycle, credentials, task-dispatch deadlines, or runtime tool policy.

## Contract

- Hermes auto-reply remains opt-in via `A2A_HERMES_AUTO_REPLY=true` (set by the
  standard Hermes installer). Legacy callback mode remains compatible.
- A private, fsynced turn journal is written before invoking the runtime. Inbound
  duplicates share one job; conversations execute serially with up to four active
  conversations per owner. Final assistant output is persisted before publishing.
- Synchronous Responses chat uses a bridge-owned HTTP connection, without the
  task delivery timeout or a consumer AbortSignal. Closing App or cancelling a
  wait does not cancel this connection. Real runtime errors are not hidden.
- When the owner has configured a compatible `/v1/runs` endpoint, the bridge
  saves the returned run ID before polling. Interrupted polls resume that ID;
  they never repeat the POST. Do not switch private runtimes without verifying
  endpoint/version support and their retention/restart guarantees.
- A bridge process restart during synchronous Responses has no recoverable run
  ID. It is marked uncertain, never silently replayed. A lost run-creation response
  is also uncertain. This release does not claim arbitrary runtime-crash recovery.
- Replies have stable IDs, completion timestamps and replyTo correlation. The
  private outbox repairs/appends canonical history before every transmission and
  retries after authenticated reconnect or missing ACK. ACK confirms router
  acceptance, not that a human read the reply. Receivers must deduplicate IDs.
- Direct conversations use the replying agent as canonical history host. Shared
  conversations with a separate offline history host still require that host's
  persistence receipt for stronger cross-host history guarantees; router ACK
  alone does not provide one.
- Progress uses transient typing frames with optional replyTo/phase fields.
  No new Firestore message bodies or progress writes are introduced. Updated App
  shows a nonterminal long-wait notice and merges history after reconnect/refocus.

## Release gates

1. Review and merge A2A; publish the exact merged 0.12.67 commit via the existing
   trusted npm workflow. Local packaging is not registry publication.
2. Deploy the compatible Chat progress forwarding and App reconciliation to Dev.
3. Update the invited agent through the standard owner-approved mechanism; verify
   installed version and auto-reply configuration without exposing private data.
4. Run a harmless >240-second task through App. Leave before completion, return,
   reload and verify a single final bubble/history entry. Do not use Voice
   activation or access the private host as a substitute for this test.
5. Promote only after this live Dev gate; preserve private turn/outbox files
   through bridge upgrades. Rolling back App/Chat must not erase these journals.

## Local verification

- Unit and real-socket tests cover consumer aborts, interrupted response bodies,
  persisted results, lost ACK, reconnect, replay deduplication, bounded concurrency
  and saved-run recovery.
- `PERKOS_CHAT_LONG_TEST_MS=301000 npm test -- tests/chat-runtime-http.integration.test.ts`
  runs the synthetic HTTP regression for more than five real minutes. It is not
  a private Hermes or deployed Dev E2E.
