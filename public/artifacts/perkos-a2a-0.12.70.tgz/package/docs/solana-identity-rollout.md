# Case-safe wallet identity preparation

Solana accounts are independent of EVM accounts. The HTTP and embedded chat
bridges now share the same validated identity parser. Valid EVM addresses retain
lowercase normalization; Solana public keys retain their exact base58 case.
Conversation token scopes and trusted dispatcher board context follow the same
rule. This does not link accounts or grant any extra permissions.

The shared contract is pinned to a public HTTPS Git commit. Local verification:
236 tests passing, TypeScript and bundled build passing, clean dependency install.
Synthetic fixtures cover exact reply identity, neutral model-facing labels and
trusted dispatcher checks. Existing EVM fixtures now use full valid addresses.

Tools tokens now carry an explicit Solana chain claim, preserve exact identity
and resolve initial Solana callers to user role. The board MCP server no longer
lowercases its configured Solana owner. Invalid identities fail before minting.
A real loopback MCP request verifies owner scope; the compiled signer was also
checked against the compiled Platform Tools verifier using synthetic identities.

This change alone does not enable Solana. App/API/Chat/Tools gates remain disabled
and browser E2E with a real user signature is pending. Platform Tools must deploy
its matching verifier before enabling Solana tool calls. No npm version was
published and no private agent host was accessed or updated. Version 0.12.68 is
already published; manifests prepare the next release, 0.12.69. Publish only from
the reviewed merge via the regular release process, never overwrite a release.
